1. To run testcases:
   ghc -o tree tree.hs
   ./tree
2. To call the function
   ghci
   :l "tree.hs"
   testcases : for running the testcases
   interactive : for giving the input yourself
3. Input Constraint
   It takes positive numbers without sign and negative numbers with sign.
   Only integers allowed.
