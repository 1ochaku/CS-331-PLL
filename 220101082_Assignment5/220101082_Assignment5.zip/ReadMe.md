# How to run the Program

1. Open the terminal
2. Enter: swipl
3. Load the file: [basicProlog].
4. Call the function:
   a. has_duplicates({.}).
   b. squareroot({.}).
5. To exit the interactive program: halt.
6. Input for task 1: numbers or chars.
7. Input for task 2: both accuracy and x should be positive.
